# -*- coding: utf-8 -*-
import hop,plugintools,urllib,xbmcplugin,xbmc,xbmcgui

def get_shows(page='1'):
#     url = 'http://www.hop.co.il/%D7%AA%D7%9B%D7%A0%D7%99%D7%95%D7%AA/page/'+page    
#     showsList = hop.get_page(url)   
#     for show in showsList:
#         plugintools.add_item(title=show.get('title'),action='showepisodes',page='1',url=show.get('url'),thumbnail=show.get('image'))
#      
#     
#     url = 'http://www.hop.co.il/%D7%AA%D7%9B%D7%A0%D7%99%D7%95%D7%AA/page/'+str(int(page)+1)    
#     showsList = hop.get_page(url)  
#     for show in showsList:
#         plugintools.add_item(title=show.get('title'),action='showepisodes',page='1',url=show.get('url'),thumbnail=show.get('image'))
    
    for x in range(int(page), int(page) + 2):        
        add_shows_item(x)   
    
    url = 'http://www.hop.co.il/%D7%AA%D7%9B%D7%A0%D7%99%D7%95%D7%AA/page/'+str(x+1)    
    showsList = hop.get_page(url) 
    if len(showsList) >2:   
        plugintools.add_item(title=u'הבא',page=str(int(page)+2),action='showlist')
    
    plugintools.close_item_list()
    
def add_shows_item(page='1'):
    url = 'http://www.hop.co.il/%D7%AA%D7%9B%D7%A0%D7%99%D7%95%D7%AA/page/'+str(page)  
    showsList = hop.get_page(url)  
    for show in showsList:
        plugintools.add_item(title=show.get('title'),action='showepisodes',page='1',url=show.get('url'),thumbnail=show.get('image'))    
     
    
def get_episodes(url,page):
    epsList = hop.get_page(url+'/page/'+page)    
    for episode in epsList:
        plugintools.add_item(title=episode.get('title'),action='stream',page='1',url=episode.get('url'),thumbnail=episode.get('image'))
    
    
    epsListNext = hop.get_page(url+'/page/'+str(int(page)+1))
    if len(epsListNext) > 2:
        plugintools.add_item(title=u'הבא',page=str(int(page)+1),action='showepisodes',url=url)
    plugintools.close_item_list()
    
def stream(url,title,thumbnail):
    path=hop.getEpisode(url)
    li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail,path=path)
    li.setInfo(type='Video', infoLabels={ "Title": str(title) })
    xbmc.Player().play(path,li)
    
def run():
    params = plugintools.get_params()
    action = params.get('action')
    if action == None:
        get_shows()
    elif action == 'showlist':
        get_shows(params.get('page'))
    elif action == 'showepisodes':
        get_episodes(params.get('url'),params.get('page'))
    elif action == 'stream':
        stream(urllib.unquote_plus(params.get('url')),urllib.unquote_plus(params.get('title')),urllib.unquote_plus(params.get('thumbnail')))
    
run()
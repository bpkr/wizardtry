# -*- coding: utf-8 -*-
import requests,urllib2
from bs4 import BeautifulSoup
import re,json

def get_page(url):
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text,'html.parser')
    ul = soup.find('ul',{'id':'jCarouselLiteUL'})
    showsList = []
    for link in ul.findAll('a'):
        clearText = re.compile('[^" ""\n""\r"]+', re.UNICODE).findall(link.find('h2').text)
        finalText =' '
        urlLink = link.get('href')
        if 'luli' not in urlLink:
            urlLink ='http://luli.tv/'+urlLink
        showsList.append({'title':finalText.join(clearText),'url':urlLink,'image':'http://luli.tv/'+link.img.get('src')})
    return showsList
    
def getEpisode(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text,'html.parser')
    r = requests.get(soup.find('iframe').get('src'))
    soup = BeautifulSoup(r.text,'html.parser')
    brightcove = soup.find('div',{'id':'main'})
    dvi = brightcove.find('video').get('data-video-id')
    da = brightcove.find('video').get('data-account')
    return getVideo(da,dvi)

def getVideo(da,dvi):
                
        headers = {
                'Accept': 'application/json;pk=BCpkADawqM2Iex_b1WSK2quDwI8rzeJpxe1cA0RwpDEY17exErxs1Adnvf7j-PKUj9FI8tihvMonKjBIBcBGLij2stKlQW241mZpYKa4d9L9lrmao59EDzbVbx6NGYkc-Zay3zWMPGdrOo-i'
            }
        
        html = requests.get('https://edge.api.brightcove.com/playback/v1/accounts/'+da+'/videos/'+dvi,headers=headers)

        a = json.loads(html.content)
        try:
             return a['sources'][1]['src']

        except:
             pass
         